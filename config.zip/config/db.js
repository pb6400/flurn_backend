const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    // Replace '<your-database-url>' with your actual MongoDB connection string
    await mongoose.connect('mongodb+srv://Easyhaiba01:Easyhaiba01@cluster0.df6lr.mongodb.net/?retryWrites=true&w=majority', {});
    console.log('Connected to the database');
  } catch (error) {
    console.error('Failed to connect to the database:', error);
    process.exit(1);
  }
};

module.exports = connectDB;
