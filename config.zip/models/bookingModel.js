const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  seatIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Seat' }],
  name: { type: String, required: true },
  phoneNumber: { type: String, required: true },
  price: { type: Number, required: true },
});

const Booking = mongoose.model('Booking', bookingSchema);

module.exports = Booking;
