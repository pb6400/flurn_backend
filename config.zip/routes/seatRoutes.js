const express = require('express');
const router = express.Router();
const seatController = require('../controllers/seatController');

// GET /seats
router.get('/', seatController.getAllSeats);

// GET /seats/:id
router.get('/:id', seatController.getSeatPricing);

module.exports = router;
