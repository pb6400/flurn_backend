const Booking = require('../models/bookingModel');
const Seat = require('../models/seatModel');

// Get all bookings
exports.getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find();
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch bookings' });
  }
};

// Create a booking
exports.createBooking = async (req, res) => {
  const { seatIds, name, phoneNumber } = req.body;

  try {
    // Check if seats are already booked
    const alreadyBookedSeats = await Seat.find({ _id: { $in: seatIds }, isBooked: true });
    if (alreadyBookedSeats.length > 0) {
      return res.status(400).json({ error: 'One or more seats are already booked' });
    }

    // Get seat class and calculate pricing
    const seatClass = await Seat.findById(seatIds[0]).select('seatClass');
    const bookingsForClass = await Booking.countDocuments({ seatClass: seatClass.seatClass });
    const seatsInClass = await Seat.countDocuments({ seatClass: seatClass.seatClass });

    let price;
    if (bookingsForClass / seatsInClass < 0.4) {
      price = seatClass.minPrice || seatClass.normalPrice;
    } else if (bookingsForClass / seatsInClass < 0.6) {
      price = seatClass.normalPrice || seatClass.maxPrice;
    } else {
      price = seatClass.maxPrice || seatClass.normalPrice;
    }

    // Create booking
    const booking = new Booking({
      seatIds,
      name,
      phoneNumber,
      price,
    });

    // Mark seats as booked
    await Seat.updateMany({ _id: { $in: seatIds } }, { isBooked: true });

    // Save booking
    const savedBooking = await booking.save();

    res.status(201).json({ booking: savedBooking });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create booking' });
  }
};

// Retrieve bookings by user identifier (email or phone number)
exports.getBookingsByUserIdentifier = async (req, res) => {
  const { userIdentifier } = req.query;

  try {
    if (!userIdentifier) {
      return res.status(400).json({ error: 'User identifier not provided' });
    }

    const bookings = await Booking.find({ $or: [{ email: userIdentifier }, { phoneNumber: userIdentifier }] });
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch bookings' });
  }
};
