const Seat = require('../models/seatModel');

// Get all seats
exports.getAllSeats = async (req, res) => {
  try {
    const seats = await Seat.find().sort('seatClass');
    res.json(seats);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch seats' });
  }
};

// Get seat pricing
exports.getSeatPricing = async (req, res) => {
  const { id } = req.params;

  try {
    const seat = await Seat.findById(id);
    if (!seat) {
      return res.status(404).json({ error: 'Seat not found' });
    }

    const bookingsForClass = await Booking.countDocuments({ seatClass: seat.seatClass });
    const seatsInClass = await Seat.countDocuments({ seatClass: seat.seatClass });

    let price;
    if (bookingsForClass / seatsInClass < 0.4) {
      price = seat.minPrice || seat.normalPrice;
    } else if (bookingsForClass / seatsInClass < 0.6) {
      price = seat.normalPrice || seat.maxPrice;
    } else {
      price = seat.maxPrice || seat.normalPrice;
    }

    res.json({ seat, price });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch seat pricing' });
  }
};
